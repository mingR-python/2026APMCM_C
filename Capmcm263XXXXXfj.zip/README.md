# Support Materials — 2026 APMCM Problem C

This archive contains the code, results and figures for the solution paper
"Acoustic Communication and Playback Responses of African Penguins at Sea".
It does NOT contain the original competition data (Data01-Data11, Supplementary1-5),
as required by the submission specification.

## Structure
- code/
  - generate.py, generate_en.py : main pipeline (Q1-Q4 tables, figures, numbers)
  - make_figs.py                : all paper figures
  - q1_q2.py                    : Q1/Q2 (classification, nonparametric tests, fidelity/decay)
  - generate_q3q4_cei.py        : Q3/Q4 (paired McNemar, GEE, 8 combinations, AFT, CEI, block bootstrap)
  - replication_scripts/        : independent replication / verification scripts
- results/                      : 10 result CSVs for Q3/Q4 (see MANIFEST.txt)
- figures/                      : fig0-fig8 (paper figures)
- MANIFEST.txt                  : English/Chinese filename map and file descriptions

## Environment
Python 3.13+ with pandas, numpy, scipy, statsmodels, lifelines, matplotlib, openpyxl.
Paper typeset with XeLaTeX (apmcmthesis.cls).

## Data
Scripts expect the competition data under
  输出/00_原始资料解包/.../2026 APMCM Problem C/date/
Change the DATA variable at the top of each script if your path differs.

## Run order
1. python generate.py        (or generate_en.py for the English paper)
2. python make_figs.py
3. xelatex main.tex (twice, for the table of contents)

## Notes
- The three correlation metrics are not independent: spectrogram and amplitude
  spectrum are correlated at r = 0.81-0.97; equal weights therefore double-count.
  PCA1 weights are reported as a sensitivity.
- The 300 propagation rows are 30 blocks x 10 rows, not 300 independent trials;
  all confidence intervals use a block bootstrap (30 blocks), not i.i.d. rows.
- Non-responses are right-censored at an assumed 60 s observation window; they are
  not evidence of non-perception.
